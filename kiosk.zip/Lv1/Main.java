package com.example.kiosk.Lv1;

import java.util.Scanner;


//Lv.1

//    햄버거 메뉴 출력 및 선택
//lv.1-1. 스캐너(Scanner)를 사용하여 여러가지의 햄버거 메뉴 및 종료버튼 출력
//lv.1-1-1. 명령어 "메뉴"를 입력하면 햄버거 메뉴 및 종료버튼이 출력되도록 작성
//lv.1-2. 제시된 메뉴중 입력받은 숫자에 따라 다른로직을 실행하는 코드작성
//lv.1-2-1. 선택한 번호에 따라 어떤 메뉴를 선택하였는지 메세지가 출력 되도록 설정
//lv.1-3. 반복문을 이용하여 종료버튼에 해당하는 숫자를 입력하면 프로그램을 종료하도록 작성
//lv.1-3-1. while문을 사용하여 해당조건에 충족되면 종료되도록 작성
public class Main {

    public static void main(String[] args) {

        //lv.1-1. 스캐너(Scanner)를 사용하여 여러가지의 햄버거 메뉴 및 종료버튼 출력
        //lv.1-1-1. 명령어 "메뉴"를 입력하면 햄버거 메뉴 및 종료버튼이 출력되도록 작성

        Scanner sc = new Scanner(System.in);

        System.out.println("메뉴를 보려면 \"menu\"를 입력해주세요");
        System.out.println("종료를 원하신다면 \"0\"을 입력해주세요");

        String input = sc.nextLine();
        String end = "";


        //lv.1-3. 반복문을 이용하여 종료버튼에 해당하는 숫자를 입력하면 프로그램을 종료하도록 작성
        //lv.1-3-1. while문을 사용하여 해당조건에 충족되면 종료되도록 작성

        while (!end.equals("0")) {
            if (input.equals("menu")) {
                hamburgerMenu();

                System.out.println("원하는 메뉴를 선택해 주세요");

                String choice = sc.nextLine();

                //lv.1-2. 제시된 메뉴중 입력받은 숫자에 따라 다른로직을 실행하는 코드작성
                //lv.1-2-1. 선택한 번호에 따라 어떤 메뉴를 선택하였는지 메세지가 출력 되도록 설정

                switch (choice) {
                    case "1":
                        System.out.println("ShackBurger를 선택하셨습니다. ");
                        break;
                    case "2":
                        System.out.println("SmokeShack를 선택하셨습니다. ");
                        break;
                    case "3":
                        System.out.println("Cheeseburger를 선택하셨습니다. ");
                        break;
                    case "4":
                        System.out.println("Hamburger를 선택하셨습니다. ");
                        break;
                    case "0":
                        System.out.println("종료합니다");
                        break;

                    default:
                        System.out.println("잘못누르셨습니다. 다시선택해주세요(1~4)");
                        continue;
                }
                break;
            } else if (input.equals("0")) {
                System.out.println("종료되었습니다!");
                break;
            } else {
                System.out.println("잘못 입력하셨습니다. \"0\"을 입력하여 종료해주세요. ");
            }

            end = sc.next();
        }
    }

    public static void hamburgerMenu() {
        System.out.println("1" + ". ShackBurger | W 6.9 | 토마토, 양상추, 쉑소스가 토핑된 치즈버거");
        System.out.println("2" + ". SmokeShack | W 8.9 | 베이컨, 체리 페퍼에 쉑소스가 토핑된 치즈버거");
        System.out.println("3" + ". Cheeseburger | W 6.9 | 포테이토번과 비프패티, 치즈가 토핑된 치즈버거");
        System.out.println("4" + ". Hamburger | W 5.4 | 비프패티를 기반으로 야채가 들어간 기본버거");
        System.out.println("0" + ". 종료 | 종료");
        System.out.println();
    }
}

