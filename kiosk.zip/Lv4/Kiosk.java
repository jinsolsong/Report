package com.example.kiosk.Lv4;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Kiosk {

    private final ArrayList<Menu> menus;

    public Kiosk(ArrayList<Menu>menus){
        this.menus = menus;
    }


    public void start() {
        Scanner sc = new Scanner(System.in);

        System.out.println("메뉴를 보려면 \"menu\"를 입력해주세요");
        System.out.println("종료를 원하신다면 \"0\"을 입력해주세요");

        String input = sc.nextLine();
        String end = "";
        while (!end.equals("0")) {
            if (input.equals("menu")) {
                System.out.println("1. 햄버거 메뉴");
                System.out.println("2. 음료 메뉴");
                System.out.println("3. 사이드 메뉴");
                System.out.println("0. 종료");
                System.out.println();
                System.out.println("원하는 메뉴를 선택하세요");

                String choice = sc.nextLine();
                switch (choice) {
                    case "1":
                        System.out.println("[ BURGERS MENU ]");
                        menus.get(0).printMenus();
                        System.out.println("0. 뒤로가기");
                        break;
                    case "2":
                        System.out.println("[ DRINK MENU ]");
                        menus.get(1).printMenus();
                        break;
                    case "3":
                        System.out.println("[ SIDE MENU ]");
                        menus.get(2).printMenus();
                        break;
                    case"0":
                        break;
                }
                System.out.println();
                System.out.println("원하는 메뉴를 고르세요!");


            }
            end = sc.next();
        }
    }


}













