package com.example.kiosk.Lv4;

import java.util.ArrayList;
import java.util.List;
//이름, 가격, 설명 필드선언하여 관리..
public class MenuItem {
    int menuNumber;
    String menuName;
    double menuPrice;
    String menuDescription;

    public MenuItem(int menuNumber, String menuName, double menuPrice, String menuDescription){
        this.menuNumber = menuNumber;
        this.menuName = menuName;
        this.menuPrice = menuPrice;
        this.menuDescription = menuDescription;
    }
    public MenuItem(int menuNumber, String menuDescription){
        this.menuNumber = menuNumber;
        this.menuDescription = menuDescription;
    }

    public String getMenuName() {
        return menuName;
    }

    public double getMenuPrice() {
        return menuPrice;
    }

    public String getMenuDescription() {
        return menuDescription;
    }
//    @Override
//    public String toString(){
//        return "선택한 메뉴 : " + menuName + " | " + menuPrice + " | " + menuDescription;
//    }


}







