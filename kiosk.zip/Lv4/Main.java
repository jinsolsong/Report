package com.example.kiosk.Lv4;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        ArrayList<Menu> menus = new ArrayList<>();

        Menu burgerMenu = new Menu("Hamburger");
        burgerMenu.addMenu(new MenuItem(1,"ShackBurger",6.9, "토마토, 양상추, 쉑소스가 토핑된 치즈버거"));
        burgerMenu.addMenu(new MenuItem(2,"SmokeShack",8.9, "베이컨, 체리 페퍼에 쉑소스가 토핑된 치즈버거"));
        burgerMenu.addMenu(new MenuItem(3,"Cheeseburger",6.9, "포테이토 번과 비프패티, 치즈가 토핑된 치즈버거"));
        burgerMenu.addMenu(new MenuItem(4,"Hamburger",5.4, "비프패티를 기반으로 야채가 들어간 기본버거"));


        Menu drinkMenu = new Menu("Drink");
        drinkMenu.addMenu(new MenuItem(1,"coke",2.8, "탄산 폭발"));
        drinkMenu.addMenu(new MenuItem(2,"cherry_coke",3.5, "체리맛 탄산 폭발"));
        drinkMenu.addMenu(new MenuItem(3,"lemon_ade",4.0, "레몬맛 탄산 폭발"));
        drinkMenu.addMenu(new MenuItem(4,"bangshaw",3.8, "계피랑 과일맛나는 끓인 포도주"));

        Menu sideMenu = new Menu("Side");
        sideMenu.addMenu(new MenuItem(1,"cheeseStick",3.4, "치즈들은 막대기"));
        sideMenu.addMenu(new MenuItem(2,"longCheeseStick",3.0, "길은 치즈들은 막대기"));
        sideMenu.addMenu(new MenuItem(3,"chickenNugget",3.7, "닭고기 튀긴거"));

        menus.add(burgerMenu);
        menus.add(drinkMenu);
        menus.add(sideMenu);



        Kiosk kiosk = new Kiosk(menus);
        kiosk.start();
    }
}
