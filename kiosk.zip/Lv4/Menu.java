package com.example.kiosk.Lv4;

import java.util.ArrayList;
import java.util.List;
// MenuItem클래스를 List로 관리
// List에 들어있는 MenuItem을 순차적으로 보여주는 함수
// List를 리턴하는 함수

public class Menu{

    String categoryName;
    List<MenuItem>menuItems;


    public Menu(String categoryName){
        this.categoryName = categoryName;
        this.menuItems = new ArrayList<>();
    }

    public String getCategoryName() {
        return categoryName;
    }

    public List<MenuItem> getMenuItems() {
        return menuItems;
    }

    public void addMenu(MenuItem item){
        menuItems.add(item);
    }

    public void printMenus(){
        for(MenuItem menuItem : menuItems){

            System.out.println(menuItem.menuNumber+". "+ menuItem.menuName+" | "+menuItem.menuPrice+" | "+menuItem.menuDescription);
        }

    }


}






