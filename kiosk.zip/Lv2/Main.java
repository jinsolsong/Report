package com.example.kiosk.Lv2;

// Lv.2

//MenuItem 클래스 생성 및 설계
//lv.2-1. 개별 음식 항목을 관리하는 클래스이며, 현재는 햄버거만관리한다.
//lv.2-1-1. 추후 다른 음식항목에 대한 관리도 하겠지만 현재는 햄버거에 대한 관리만 진행
//lv.2-1-2. 클래스는 이름,가격,설명 필드를 갖는다.(필드생성 "이해완료")
//
//lv.2-2.main함수에서 MenuItem클래스를 활용하여 햄버거 메뉴를 출력한다.
//lv.2-2-1.MenuItem 객체생성을 통해 이름,가격,설명을 세팅한다.
//lv.2-2-1-1. 키워드new를 사용함...
//lv.2-2-2. List를 선언하여 여러 MenuItem을 추가한다.
//lv.2-2-2-1. List<MenItem>menuItems = new ArrayList<>();
//       .add사용
//lv.2-2-3. 반복문을 활용해 menuItems를 탐색하며 하나씩 접근한다.
//     for문을 이용해서 실행예정

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



public class Main {

    public static void main(String[] args) {

        //lv.2-2.main함수에서 MenuItem클래스를 활용하여 햄버거 메뉴를 출력한다.
        //lv.2-2-1.MenuItem 객체생성을 통해 이름,가격,설명을 세팅한다.
        //lv.2-2-1-1. 키워드new를 사용함...
        //lv.2-2-2. List를 선언하여 여러 MenuItem을 추가한다.
        //lv.2-2-2-1. List<MenItem>menuItems = new ArrayList<>();
        //          .add사용


        List<MenuItem> menuItems = new ArrayList<>();

        MenuItem burger1 = new MenuItem(1, "ShackBurger", 6.9, "토마토, 양상추, 쉑소스가 토핑된 치즈버거");
        MenuItem burger2 = new MenuItem(2, "SmokeShack", 8.9, "베이컨, 체리 페퍼에 쉑소스가 토핑된 치즈버거");
        MenuItem burger3 = new MenuItem(3, "Cheeseburger", 6.9, "포테이토번과 비프패티, 치즈가 토핑된 치즈버거");
        MenuItem burger4 = new MenuItem(4, "Hamburger", 5.4, "비프패티를 기반으로 야채가 들어간 기본버거");

        menuItems.add(burger1);
        menuItems.add(burger2);
        menuItems.add(burger3);
        menuItems.add(burger4);

        Scanner sc = new Scanner(System.in);

        System.out.println("메뉴를 보려면 \"menu\"를 입력해주세요");
        System.out.println("종료를 원하신다면 \"0\"을 입력해주세요");

        String input = sc.nextLine();
        String end = "";


        while (!end.equals("0")) {
            if (input.equals("menu")) {

                //lv.2-2-3. 반복문을 활용해 menuItems를 탐색하며 하나씩 접근한다.
                //          for문을 이용해서 실행예정
                for (MenuItem menuItem : menuItems) {
                    System.out.println(menuItem.burgerSequence + ". " + menuItem.burgerName + " | " + menuItem.burgerPrice + " | " + menuItem.burgerDescription);
                }
                System.out.println("종료를 원하시면 \"0\"을 입력해주세요.");
                System.out.println("원하는 메뉴를 선택해 주세요");

                String choice = sc.nextLine();

                switch (choice) {
                    case "1":
                        burger1.printBurger();
                        break;
                    case "2":
                        burger2.printBurger();
                        break;
                    case "3":
                        burger3.printBurger();
                        break;
                    case "4":
                        burger4.printBurger();
                        break;
                    case "0":
                        System.out.println("종료합니다");
                        break;

                    default:
                        System.out.println("잘못누르셨습니다. 다시선택해주세요(1~4)");
                        continue;
                }
                break;
            } else if (input.equals("0")) {
                System.out.println("종료되었습니다!");
                break;
            } else {
                System.out.println("잘못 입력하셨습니다. \"0\"을 입력하여 종료해주세요. ");
            }

            end = sc.next();
        }
    }

}

