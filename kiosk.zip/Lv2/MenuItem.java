package com.example.kiosk.Lv2;

public class MenuItem {
    //lv.2-1. 개별 음식 항목을 관리하는 클래스이며, 현재는 햄버거만관리한다.
    //lv.2-1-1. 추후 다른 음식항목에 대한 관리도 하겠지만 현재는 햄버거에 대한 관리만 진행
    //lv.2-1-2. 클래스는 이름,가격,설명 필드를 갖는다.(필드생성 "이해완료")
    //필드
    int burgerSequence;
    String burgerName;
    double burgerPrice;
    String burgerDescription;

    //생성자
    public MenuItem(int burgerSequence, String burgerName, double burgerPrice, String burgerDescription) {
        this.burgerSequence = burgerSequence;
        this.burgerName = burgerName;
        this.burgerPrice = burgerPrice;
        this.burgerDescription = burgerDescription;
    }

    //메서드(출력문 세팅)
    public void printBurger() {
        System.out.println("선택한 메뉴 : " + burgerName + " | " + burgerPrice + " | " + burgerDescription);
    }
}
