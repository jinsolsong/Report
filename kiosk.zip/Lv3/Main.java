package com.example.kiosk.Lv3;

import java.util.ArrayList;
import java.util.Scanner;
// Lv.3

//Kiosk 클래스 생성하기
//lv.3-1 MenuItem을 관리하는 리스트가 Kiosk클래스에 필드로 존재한다.
//lv.3-2 Main함수에서 관리하던 입력과 반복문 로직을 이제는 start함수를 만들어서 관리한다.
//lv.3-3 List<MenuItem>menuItems는 Kiosk클래스 생성자를 통해 값을 할당한다.
//lv.3-3-1 Kiosk객체를 생성하고 사용하는 main함수에서 객체를 생성할 때 값을 넘겨줍니다.

//요구사항에 부합하는지 검토
//- 키오스크 프로그램을 시작하는 메서드가 구현되어야 한다.
//- 콘솔에 햄버거 메뉴를 출력한다.
//- 사용자의 입력을 받아 메뉴를 선택하거나 프로그램을 종료한다.
//- 유효하지 않은 입력에 대해 오류 메세지를 출력한다.
//- 0을 입력하면 프로그램이 뒤로가기 되거나 종료된다
public class Main {

    public static void main(String[] args) {


        ArrayList<MenuItem>menuItems = new ArrayList<>();

        MenuItem burger1 = new MenuItem(1,"ShackBurger", 6.9,"토마토, 양상추, 쉑소스가 토핑된 치즈버거" );
        MenuItem burger2 = new MenuItem(2,"SmokeShack", 8.9,"베이컨, 체리 페퍼에 쉑소스가 토핑된 치즈버거" );
        MenuItem burger3 = new MenuItem(3,"Cheeseburger", 6.9,"포테이토번과 비프패티, 치즈가 토핑된 치즈버거" );
        MenuItem burger4 = new MenuItem(4,"Hamburger", 5.4,"비프패티를 기반으로 야채가 들어간 기본버거" );

        menuItems.add(burger1);
        menuItems.add(burger2);
        menuItems.add(burger3);
        menuItems.add(burger4);


        Kiosk kiosk = new Kiosk(menuItems);

        Scanner sc = new Scanner(System.in);

        kiosk.start();

    }
}


