package com.example.kiosk.Lv3;

import static javax.swing.UIManager.get;

public class MenuItem {

    int burgerSequence;
    String burgerName;
    double burgerPrice;
    String burgerDescription;

    //생성자
    public MenuItem(int burgerSequence, String burgerName, double burgerPrice, String burgerDescription) {
        this.burgerSequence = burgerSequence;
        this.burgerName = burgerName;
        this.burgerPrice = burgerPrice;
        this.burgerDescription = burgerDescription;
    }

    //메서드(출력문 세팅)

    public void printBurger(){
        System.out.println("선택한 메뉴 : " + burgerName + " | " + burgerPrice + " | " + burgerDescription);
    }


}
