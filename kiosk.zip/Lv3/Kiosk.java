package com.example.kiosk.Lv3;

//Kiosk 클래스 생성하기
//lv.3-1 MenuItem을 관리하는 리스트가 Kiosk클래스에 필드로 존재한다.
//lv.3-2 Main함수에서 관리하던 입력과 반복문 로직을 이제는 start함수를 만들어서 관리한다.
//lv.3-3 List<MenuItem>menuItems는 Kiosk클래스 생성자를 통해 값을 할당한다.
//lv.3-3-1 Kiosk객체를 생성하고 사용하는 main함수에서 객체를 생성할 때 값을 넘겨줍니다.

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Kiosk {

    //lv.3-1 MenuItem을 관리하는 리스트가 Kiosk클래스에 필드로 존재한다.

    Scanner sc = new Scanner(System.in);

    List<MenuItem> menuItems;

    //생성자
    //lv.3-3 List<MenuItem>menuItems는 Kiosk클래스 생성자를 통해 값을 할당한다.
    public Kiosk(List<MenuItem>menuItems){
    //매개변수
        this.menuItems = menuItems;
    }


    //메서드
    //lv.3-2 Main함수에서 관리하던 입력과 반복문 로직을 이제는 start함수를 만들어서 관리한다.
    public void start(){




        System.out.println("메뉴를 보려면 \"menu\"를 입력해주세요");
        System.out.println("종료를 원하신다면 \"0\"을 입력해주세요");

        String input = sc.nextLine();
        String end = "";
        while (!end.equals("0")) {
            if (input.equals("menu")) {

                for (MenuItem menuItem : menuItems){
                    System.out.println(menuItem.burgerSequence+". "+menuItem.burgerName+ " | " + menuItem.burgerPrice + " | "  + menuItem.burgerDescription );
                }


                System.out.println("0. 종료 | 종료");
                System.out.println("원하는 메뉴를 선택해 주세요");

                String choice = sc.nextLine();

                //*****디스플레이..

                switch (choice){
                    case "1":
                        menuItems.get(0).printBurger();
                        break;
                    case "2":
                        menuItems.get(1).printBurger();
                        break;
                    case "3":
                        menuItems.get(2).printBurger();
                        break;
                    case "4":
                        menuItems.get(3).printBurger();
                        break;
                    case "0":
                        System.out.println("종료합니다");
                        break;

                    default:
                        System.out.println("잘못누르셨습니다. 다시선택해주세요(1~4)");
                        continue;
                }
                break;

            } else if (input.equals("0")) {
                System.out.println("종료되었습니다!");
                break;
            }else{
                System.out.println("잘못 입력하셨습니다. \"0\"을 입력하여 종료해주세요. ");
            }

            end = sc.next();
        }


    }

    }



